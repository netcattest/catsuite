CatBridge | NetCatTest
https://netcattest.com/catsuite
https://github.com/netcattest/catsuite/tree/main/catbridge

PORTUGUES BRASILEIRO

Este pacote e portatil. Extraia todos os arquivos antes de executar.
Abra um terminal na pasta extraida. Substitua 192.168.1.20 pelo IP local
do computador que o celular pode acessar. Nao e necessario compilar.

Windows:
.\catbridge.exe serve -state .\private-state -listen 0.0.0.0:8743 -public https://192.168.1.20:8743

Linux:
./catbridge serve -state ./private-state -listen 0.0.0.0:8743 -public https://192.168.1.20:8743

No CatSuite, ative Configuracoes > Extensoes e abra
Extensoes > Conexoes > Parear CatBridge. Informe o endereco e o codigo
temporario mostrado no terminal. Mantenha o terminal aberto.

Ferramentas externas requerem instalacao e autorizacao separadas.
Este pacote nao inclui Docker, Nuclei ou executores de terceiros.
Mantenha a pasta private-state privada e use ambientes autorizados.

ENGLISH

This package is portable. Extract all files before running it.
Open a terminal in the extracted folder. Replace 192.168.1.20 with
your computer's local IP address reachable from the phone.
No compilation is needed.

Windows:
.\catbridge.exe serve -state .\private-state -listen 0.0.0.0:8743 -public https://192.168.1.20:8743 -lang en

Linux:
./catbridge serve -state ./private-state -listen 0.0.0.0:8743 -public https://192.168.1.20:8743 -lang en

In CatSuite, enable Settings > Extensions, then open
Extensions > Connections > Pair CatBridge. Enter the address and the
temporary code displayed in the terminal. Keep the terminal open.

External tools require separate installation and authorization.
Docker, Nuclei and third-party executors are not included.
Keep private-state private and use authorized environments.
